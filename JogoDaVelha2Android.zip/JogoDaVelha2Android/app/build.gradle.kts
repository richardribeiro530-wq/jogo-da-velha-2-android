plugins {
    id("com.android.application")
}

android {
    namespace = "com.gepeto.jogodavelha2"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.gepeto.jogodavelha2"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
